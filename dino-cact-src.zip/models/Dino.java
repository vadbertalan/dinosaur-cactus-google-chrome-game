// Vad Bertalan | Computer Science | UBB | 2nd year | vbim1780

package models;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/*
    class that describes the model dino
 */
public class Dino {
    public static final BufferedImage IMAGE;
    public static final int WIDTH;
    public static final int HEIGHT;
    public static final double JUMP_HEIGHT = 400;
    public static final double INITIAL_RISE_AMOUNT = 12;
    public static final double INITIAL_DESCENT_AMOUNT = 9;

    private double dinoX;
    private double dinoY;
    private boolean jumping = false;

    static {
        BufferedImage tempImage = null;
        try {
//            tempImage = ImageIO.read(new File("dino2.png"));
            tempImage = ImageIO.read(Dino.class.getResourceAsStream("/dino2.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        IMAGE = tempImage;
        WIDTH = IMAGE.getWidth();
        HEIGHT = IMAGE.getHeight();
    }

    ;

    public Dino(int dinoX, int dinoY) {
        this.dinoX = dinoX;
        this.dinoY = dinoY;
    }

    public double getDinoX() {
        return dinoX;
    }

    public void setDinoX(double dinoX) {
        this.dinoX = dinoX;
    }

    public double getDinoY() {
        return dinoY;
    }

    public void setDinoY(double dinoY) {
        this.dinoY = dinoY;
    }

    public boolean isJumping() {
        return jumping;
    }

    public void setJumping(boolean jumping) {
        this.jumping = jumping;
    }
}
