// Vad Bertalan | Computer Science | UBB | 2nd year | vbim1780

package backend;

import frontend.GamePanel;
import models.Dino;

/*
    class that is a target which is responsible for elevating the dino
 */
public class DinoRiseTarget extends Thread {
    private GamePanel gamePanel;
    private Dino dino;

    public DinoRiseTarget(GamePanel gamePanel, Dino dino) {
        this.gamePanel = gamePanel;
        this.dino = dino;
    }

    /*
        make the dino elevate until a specified amount and refreshes the gui every frame
     */
    @Override
    public void run() {
        // setting the jumping flag to true
        dino.setJumping(true);

        // this variable will be gradually decreased <=> the higher the dino is, the smaller the riseAmount will be
        double riseAmount = Dino.INITIAL_RISE_AMOUNT;

        // rise the dino 'till it hits the threshold
        while (dino.getDinoY() > gamePanel.getHeight() - Dino.JUMP_HEIGHT) {
            dino.setDinoY(dino.getDinoY() - riseAmount);
            riseAmount -= riseAmount / 100  ;

            try {
                Thread.sleep(15);
            } catch (InterruptedException e1) {
                // e1.printStackTrace();
            }

            // making the UI refresh
            gamePanel.repaint();
        }
    }
}
