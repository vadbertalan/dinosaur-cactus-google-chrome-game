// Vad Bertalan | Computer Science | UBB | 2nd year | vbim1780

package backend;

import frontend.GamePanel;
import models.Dino;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/*
    class that listens to the space bar hits
    upon using the space bar, performs a dino jump
 */
public class KeyListenerImpl extends KeyAdapter {
    private GamePanel gamePanel;
    private Dino dino;

    private Thread dinoRiseThread;
    private Thread dinoDescendThread;

    public KeyListenerImpl(GamePanel gamePanel, Dino dino) {
        this.gamePanel = gamePanel;
        this.dino = dino;
    }

    /*
        function, that upon jumping starts 2 threads:
            1. makes the dino rise
            2. makes the dino descent
     */
    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE && !dino.isJumping()) {
            dinoRiseThread = new Thread(new DinoRiseTarget(gamePanel, dino));
            dinoDescendThread = new Thread(new DinoDescendTarget(gamePanel, dino, dinoRiseThread));

            dinoRiseThread.start();
            dinoDescendThread.start();
        }
    }

    public Thread getDinoRiseThread() {
        return dinoRiseThread;
    }

    public Thread getDinoDescendThread() {
        return dinoDescendThread;
    }
}
