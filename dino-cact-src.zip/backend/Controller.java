// Vad Bertalan | Computer Science | UBB | 2nd year | vbim1780
package backend;

// todo: make gamer finer and smoother

import frontend.Frame;
import models.Cactus;
import models.Dino;

import javax.swing.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/*
    Class that is the controller of the game. Runs on a new thread.
 */
public class Controller implements Runnable {
    public static final int GROUND_HEIGHT = 40;
    public static final int HORIZONTAL_DINO_OFFSET = 40;

    private Frame frame;
    private Dino dino;
    private List<Cactus> cactuses;
    private int obstacleNumber;
    private boolean gameOver;

    private List<Thread> obstacleSpawnerThreads;

    public Controller(Frame frame, int obstacleNumber) {
        this.frame = frame;
        this.obstacleNumber = obstacleNumber;
        dino = new Dino(50, Frame.GAMEPANEL_HEIGHT - Dino.HEIGHT - Controller.GROUND_HEIGHT);
        cactuses = new LinkedList<>();
        obstacleSpawnerThreads = new ArrayList<>();
    }

    /*
        spawns n amount of obstacles
     */
    @Override
    public void run() {
            sleep(800);
            int n = 0;
            while (n < obstacleNumber && !isGameOver()) {
                // new obstacle spawns every ~3.5 seconds
                sleep(new Random().nextInt(2500) + 1000);

                // if the game ended while this thread was sleeping, the thread doesn't proceed
                if (isGameOver()) {
                    break;
                }

                // new thread that sets the x coordinate to the obstacle and checks for collisions with the dinosaur every frame
                Thread obstacleSpawnerThread = new Thread(() -> {
                    // instantiating the new cactus
                    Cactus cactus = new Cactus(frame.getGamePanel().getWidth(), frame.getGamePanel().getHeight() - Cactus.HEIGHT - Controller.GROUND_HEIGHT);

                    // adding it to the list of cactuses, so the gamePanel will know that it has to be drawn
                    cactuses.add(cactus);

                    // while the current cactus is on the list of the drawable cactuses do the job
                    while (cactuses.contains(cactus) && !isGameOver()) {
                        // making the UI refresh
                        frame.getGamePanel().repaint();

                        // upon collision
                        if (checkForCollision(dino, cactus)) {
                            setGameOver(true);

                            // stops the other important threads so the last frame stays on screen
                            frame.getKeyListener().getDinoRiseThread().interrupt();
                            frame.getKeyListener().getDinoDescendThread().interrupt();

                            // informing the user about the result of the game
                            JOptionPane.showMessageDialog(frame, "Game Over!");

                            // OPTIONAL
                            System.exit(0);
                        }

                        // doing the job every 15 milliseconds
                        sleep(10);

                        // updating the x coordinate
                        cactus.setX(cactus.getX() - Cactus.MOVE_AMOUNT);

                        // if the cactus disappeared on the left of our screen, removes it from the list which stops the while cycle
                        if (cactus.getX() + Cactus.WIDTH < 0) {
                            cactuses.remove(cactus);
                        }
                    }
                });

                // keeping a list of the spawner threads too
                obstacleSpawnerThreads.add(obstacleSpawnerThread);

                // spawning an obstacle
                obstacleSpawnerThread.start();

                // incrementing the spawned obstacle number
                n++;
            }

            // if the program reaches this point, that means the player managed not to hit the obstacles so he/she won.

            // waiting the threads to exit the screen
            obstacleSpawnerThreads.forEach(ost -> {
                try {
                    ost.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });

            // informing the user about the result of the game
            JOptionPane.showMessageDialog(frame, "You won!");

            // OPTIONAL
            System.exit(0);
    }

    /*
        function that makes the rest of the code easier to read
    */
    public void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /*
        function that checks for collisions by taking the coordinates of the middle of the dinosaur and checks if it's inside the cactus
        CAN BE MUCH MUCH BETTER :P
     */
    private boolean checkForCollision(Dino dino, Cactus cactus) {
        double dinoCenterX = (2 * dino.getDinoX() + Dino.WIDTH) / 2;
        double dinoCenterY = (2 * dino.getDinoY() + Dino.HEIGHT) / 2;
        return (dinoCenterX >= cactus.getX() && dinoCenterX <= cactus.getX() + Cactus.WIDTH && dinoCenterY >= cactus.getY() && dinoCenterY <= cactus.getY() + Cactus.HEIGHT);
    }

    public Dino getDino() {
        return dino;
    }

    /*
        note: return just a copy of the list => it can't be modified outside of this class :)
     */
    public List<Cactus> getCactuses() {
        return new LinkedList<>(cactuses);
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public void setGameOver(boolean gameOver) {
        this.gameOver = gameOver;
    }
}
