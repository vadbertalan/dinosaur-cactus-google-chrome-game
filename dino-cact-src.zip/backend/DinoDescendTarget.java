package backend;// Vad Bertalan | Computer Science | UBB | 2nd year | vbim1780

import frontend.GamePanel;
import models.Dino;

/*
    class that is a target which is responsible for making the dino fall
 */
public class DinoDescendTarget extends Thread {
    private GamePanel gamePanel;
    private Dino dino;
    private Thread threadToWait;

    public DinoDescendTarget(GamePanel gamePanel, Dino dino, Thread threadToWait) {
        this.gamePanel = gamePanel;
        this.dino = dino;
        this.threadToWait = threadToWait;
    }

    @Override
    public void run() {
        try {
            // the dino has to rise before he can start falling
            threadToWait.join();

            // this variable will be gradually increased <=> the lower the dino is, the higher the descentAmount will be
            double descentAmount = Dino.INITIAL_DESCENT_AMOUNT;

            // while the dino doesn't hit the ground fall gradually
            while (dino.getDinoY() < gamePanel.getHeight() - Dino.HEIGHT - Controller.GROUND_HEIGHT) {
                Thread.sleep(15);
                dino.setDinoY(dino.getDinoY() + descentAmount);
                descentAmount += descentAmount / 100;
                if (dino.getDinoY() + descentAmount > gamePanel.getHeight() - Dino.HEIGHT - Controller.GROUND_HEIGHT) {
                    dino.setDinoY(gamePanel.getHeight() - Dino.HEIGHT - Controller.GROUND_HEIGHT);
                }

                // making the UI refresh
                gamePanel.repaint();
            }
            dino.setJumping(false);
        } catch (InterruptedException e1) {
            // e1.printStackTrace();
        }
    }
}
