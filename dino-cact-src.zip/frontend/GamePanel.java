package frontend;// Vad Bertalan | Computer Science | UBB | 2nd year | vbim1780

import backend.Controller;
import models.Cactus;
import models.Dino;

import javax.swing.*;
import java.awt.*;

public class GamePanel extends JPanel {
    private Dino dino;
    private Cactus cactus;
    private Controller controller;

    public void setDino(Dino dino) {
        this.dino = dino;
    }

    public GamePanel(Dino dino, Controller controller) {
        this.dino = dino;
        this.controller = controller;
    }
    public void setCactus(Cactus cactus) { this.cactus = cactus; }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(2));

        if (dino.isJumping()) {
            g2.drawLine(0, getHeight() - Controller.GROUND_HEIGHT - 10, getWidth(), getHeight() - Controller.GROUND_HEIGHT - 10);
        }
        else {
            g2.drawLine(0, getHeight() - Controller.GROUND_HEIGHT - 10, Controller.HORIZONTAL_DINO_OFFSET + Dino.WIDTH / 3, getHeight() - Controller.GROUND_HEIGHT - 10);
            g2.drawLine(Controller.HORIZONTAL_DINO_OFFSET + Dino.WIDTH - Dino.WIDTH / 4, getHeight() - Controller.GROUND_HEIGHT - 10, getWidth(), getHeight()- Controller.GROUND_HEIGHT - 10);
        }

        g.drawImage(Dino.IMAGE, (int) dino.getDinoX(), (int) dino.getDinoY(), Dino.WIDTH, Dino.HEIGHT, null);

        if (controller.getCactuses().size() > 0) {
            for (Cactus cactus : controller.getCactuses()) {
                g.drawImage(Cactus.IMAGE,
                        cactus.getX(),
                        cactus.getY(),
                        Cactus.WIDTH, Cactus.HEIGHT,
                        null);
            }
        }
    }
}
