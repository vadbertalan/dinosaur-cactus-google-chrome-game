// Vad Bertalan | Computer Science | Second Year | vbim1780

package frontend;

import backend.Controller;
import backend.KeyListenerImpl;
import models.Dino;

import javax.swing.*;


/*
    class that contains the the UI and the frame's settings
 */
public class Frame extends JFrame {
    public static final int GAMEPANEL_HEIGHT = 493;
    public static final int GAMEPANEL_WIDTH = 1473;

    private GamePanel gamePanel;

    private KeyListenerImpl keyListener;

    public Frame(int obstacleNumber) {
        // setting the title of the window
        super("DinosaurCactus");

        // initializing controller stuff
        Controller controller = new Controller(this, obstacleNumber);
        Dino dino = controller.getDino();
        gamePanel = new GamePanel(dino, controller);

        // giving logic behind the UI elements
        keyListener = new KeyListenerImpl(gamePanel, dino);
        this.addKeyListener(keyListener);

        // controllers run on a separate thread
        new Thread(controller).start();

        getContentPane().add(gamePanel);
        setBounds(1920 / 9, 1080 / 4, 1920 / 9 * 7, 1080 / 2);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    public JPanel getGamePanel() {
        return gamePanel;
    }

    public KeyListenerImpl getKeyListener() {
        return keyListener;
    }
}
