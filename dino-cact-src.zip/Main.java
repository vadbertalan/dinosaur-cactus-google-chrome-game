// Vad Bertalan | Computer Science | UBB | 2nd year | vbim1780

import frontend.Frame;

public class Main {
    public static void main(String[] args) {
        int n;
        try {
            n = Integer.parseInt(args[0]);
            if (n <= 0) {
                throw new IllegalArgumentException();
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            n = 10;
        }
        Frame frame = new Frame(n);
    }
}
